import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white text-gray-800">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-teal-500 text-white py-20 px-6 text-center">
        <h1 className="text-4xl font-bold mb-4">VoltAir Solutions</h1>
        <p className="text-xl">Electrical. Air Conditioning. Renewables.</p>
        <Button className="mt-6">Get a Free Quote</Button>
      </div>

      {/* About Us */}
      <section className="p-6">
        <h2 className="text-2xl font-semibold mb-2">About Us</h2>
        <p>
          We're a North West-based team delivering high-quality air conditioning, electrical,
          and energy-efficient solutions for homes and businesses. With experience in field
          servicing, installation, and innovation, VoltAir Solutions is here to future-proof your property.
        </p>
      </section>

      {/* Services */}
      <section className="p-6 bg-gray-100">
        <h2 className="text-2xl font-semibold mb-4">Our Services</h2>
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardContent className="p-4">
              <h3 className="font-bold text-lg mb-2">Air Conditioning</h3>
              <ul className="list-disc list-inside text-sm">
                <li>Commercial & residential systems</li>
                <li>High-efficiency units</li>
                <li>Servicing & repairs</li>
              </ul>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <h3 className="font-bold text-lg mb-2">Electrical Solutions</h3>
              <ul className="list-disc list-inside text-sm">
                <li>Domestic & commercial wiring</li>
                <li>Rewiring & upgrades</li>
                <li>Fault finding, testing & certifications</li>
              </ul>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <h3 className="font-bold text-lg mb-2">Renewable Energy</h3>
              <ul className="list-disc list-inside text-sm">
                <li>Solar & battery systems (coming soon)</li>
                <li>Energy audits</li>
                <li>Eco upgrades to reduce bills</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="p-6">
        <h2 className="text-2xl font-semibold mb-4">Why Choose Us?</h2>
        <ul className="list-disc list-inside">
          <li>Qualified, experienced, and reliable</li>
          <li>Honest pricing with no hidden fees</li>
          <li>Flexible scheduling and fast response</li>
          <li>Future-focused with energy-saving goals</li>
        </ul>
      </section>

      {/* Contact Section */}
      <section className="p-6 bg-gray-100">
        <h2 className="text-2xl font-semibold mb-4">Contact Us</h2>
        <p><strong>Phone:</strong> +44 [your number]</p>
        <p><strong>Email:</strong> voltair.solutions@yourdomain.com</p>
        <p><strong>Service Area:</strong> Greater Manchester & North West</p>
        <Button className="mt-4">Book Your Free Site Assessment</Button>
      </section>
    </div>
  );
}